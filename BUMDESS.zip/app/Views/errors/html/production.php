<!doctype html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="robots" content="noindex">

    <title>Mohon Maaf</title>

    <style type="text/css">
        <?= preg_replace('#[\r\n\t ]+#', ' ', file_get_contents(__DIR__ . DIRECTORY_SEPARATOR . 'debug.css')) ?>
    </style>
</head>
<body>

    <div class="container text-center">

        <h1 class="headline">Mohon Maaf</h1>

        <p class="lead">Telah terjadi masalah, mohon hubungi pihak padanglawasutarakab.go.id</p>

    </div>

</body>

</html>
